GRANT USAGE ON *.* TO 'humberto'@'localhost' IDENTIFIED BY PASSWORD '69e872c75ce95a6f';
GRANT ALL PRIVILEGES ON `humberto`.* TO 'humberto'@'localhost';
GRANT ALL PRIVILEGES ON `humberto\_%`.* TO 'humberto'@'localhost';
