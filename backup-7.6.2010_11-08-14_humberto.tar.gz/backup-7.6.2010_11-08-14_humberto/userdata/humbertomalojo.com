--- 
customlog: 
  - 
    format: combined
    target: /usr/local/apache/domlogs/humbertomalojo.com
  - 
    format: "\"%{%s}t %I .\\n%{%s}t %O .\""
    target: /usr/local/apache/domlogs/humbertomalojo.com-bytes_log
documentroot: /home/humberto/public_html
group: humberto
hascgi: 1
homedir: /home/humberto
ifmoduleconcurrentphpc: {}

ifmodulemodsuphpc: 
  group: humberto
ip: 80.172.232.38
owner: alojamen
phpopenbasedirprotect: 1
port: 80
scriptalias: 
  - 
    path: /home/humberto/public_html/cgi-bin
    url: /cgi-bin/
  - 
    path: /home/humberto/public_html/cgi-bin/
    url: /cgi-bin/
serveradmin: webmaster@humbertomalojo.com
serveralias: www.humbertomalojo.com
servername: humbertomalojo.com
usecanonicalname: 'Off'
user: humberto
userdirprotect: ''
